/**
 * The resolver for enum Status
 */
const StatusResolver = {
  TODO: "TODO",
  INPROGRESS: "INPROGRESS",
  DONE: "DONE",
};

export default StatusResolver;
